<template>
  <div class="header-margin pb-64">
    <div>
    <div class="container w-auto">
      <p class="m-20 justify-center text-center capitalize text-4xl text-burgundy font-semibold">- Contact Us -</p>
      <div class="card grid grid-cols-3 border rounded-2xl outline-none m-8">
        <div class="contact bg-burgundy col-span-2 justify-items-center text-white grid grid-cols-3 border rounded-l-2xl p-14">
           
            <div class="m-8">
                  <img src="/icons/logomain.jpeg" alt="">
            </div>
            <div class="col-span-2 ml-20 mt-12 mb-12 ">
                <h6 class="text-right font-semibold mb-2">Jiri Women's Hostel</h6>
              <h6 class="text-right">Tezpur University <br> Napaam, Tezpur, Assam - 784028</h6> &nbsp;
              <p class="flex items-center justify-end md:justify-end hover:text-red-100">
                <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="phone"
                class="w-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512">
                <path fill="currentColor"
                  d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z">
                </path>
                </svg>
                 +91-1234506789
              </p>
              <p class="flex items-center justify-end md:justify-end mb-4">
              <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="envelope"
                class="mr-2 h-4" role="img" xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512">
                <path fill="currentColor"
                  d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z">
                </path>
              </svg>
              <a href="mailto:poonam@tezu.ernet.in" class="hover:underline hover:text-red-100">insertemail@gmail.com</a>
              </p>
              
            </div>
            <div class="three m-4">
               <p class="flex items-center justify-center md:justify-start hover:underline">
                <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="phone"
                class="w-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512">
                <path fill="currentColor"
                  d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z">
                </path>
                </svg>
                 +91-1234506789
              </p>
            </div>
            <div class="four m-4">
             <p class="flex items-center justify-center md:justify-start hover:underline">
                <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="phone"
                class="w-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512">
                <path fill="currentColor"
                  d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z">
                </path>
                </svg>
                +91-1234506789

              </p>
            </div>
            <div class="five m-4">
              <p class="flex items-center justify-center md:justify-start hover:underline">
                <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="phone"
                class="w-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 512 512">
                <path fill="currentColor"
                  d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z">
                </path>
                </svg>
                +91-1234506789

              </p>
            </div>
            <div class="six mb-6">
             
               Senior Warden
            </div>
            <div class="seven mb-6">
               Warden
            </div>
            <div class="eight mb-6">
              Prefect
            </div>
        </div>
        <div class="map border-r-2xl">
          <iframe class="border-r-2xl" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3564.268475324649!2d92.8306125148168!3d26.70386878321797!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3744ebbece98dffd%3A0x26123178980bfca4!2sJiri%20Path%2C%20Napaam%2C%20Amola%20Pam%20Gaon%2C%20Assam%20784028!5e0!3m2!1sen!2sin!4v1658437584868!5m2!1sen!2sin" width="100%" height="100%" style="border:2x; border-radius:0 15px 15px 0" allowfullscreen="" loading="lazy"></iframe>        
        </div>
      </div>
    </div>
</div>
</div>
</template>

<style lang="" scoped>

  
</style>