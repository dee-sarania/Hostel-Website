<template>
  <div>
    <Homepage/>
    
  </div>
</template>

<script>
export default{
  name: 'index'
}
</script>