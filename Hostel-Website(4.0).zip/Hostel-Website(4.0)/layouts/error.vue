<template>
    <div>Error page</div>
</template>