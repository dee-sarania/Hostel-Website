<template>
<div class="container mb-96">
          
            

   <!-- administration informantion cards -->
   <div class=" container flex items-center justify-center space-x-10">
      <div class="mt-20 max-w-sm rounded overflow-hidden shadow-lg">
         <img class="max-w-sm transform transition duration-500 hover:scale-110" src="building.jpeg" alt="Sunset in the mountains">
            <div class="px-6 py-4">
               <div class="font-semibold text-l mb-2 text-center">insert warden's name</div>
               <p class="text-gray-700 text-base text-center">
                 
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
               </p>
            </div>
      </div>
         
      <div class="max-w-sm mt-20 rounded overflow-hidden shadow-lg">
         <img class="max-w-sm transform transition duration-500 hover:scale-110" src="building2.jpeg" alt="Sunset in the mountains">
            <div class="px-6 py-4">
               <div class="font-semibold text-l mb-2 text-center">insert warden's name</div>
               <p class="text-gray-700 text-base text-center">
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
               </p>
            </div>
      </div>

      <div class="max-w-sm mt-20 rounded overflow-hidden shadow-lg">
         <img class="max-w-sm transform transition duration-500 hover:scale-110" src="deansbuilding.jpeg" alt="Sunset in the mountains">
            <div class="px-6 py-4">
               <div class="font-semibold text-l mb-2 text-center">prefect name</div>
               <p class="text-gray-700 text-base text-center">
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
               </p>
            </div>
      </div>            
   </div>
</div>




</template>