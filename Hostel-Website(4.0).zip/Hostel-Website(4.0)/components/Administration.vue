<template>
   <div class="header-margin pb-64">
      <div class="container">
         <!-- wardens informantion cards -->
         <div class="container w-full">

            <p class="capitalize pt-28 justify-left text-4xl text-burgundy font-bold">administration</p>

            <p class="mt-32 justify-center text-center capitalize text-3xl text-burgundy font-semibold">- wardens -</p>
         </div>
         <div class="container flex items-center justify-center space-x-40">

            <div class="container transform transition duration-500 hover:scale-105">
               <div class=" max-w-sm mt-8 rounded overflow-hidden shadow-lg">
                  <img class="max-w-sm object-center " src="/images/noimage.jpeg">
                  <div class="px-6 py-4">
                     <div class="mb-2 text-lg text-burgundy font-bold capitalize">dr. poonam mishra</div>
                     <p class="text-justify text-center text-base text-test font-medium font-medium leading-relaxed">
                        Associate Professor<br>Dept. of Food Engineering & Technology <br> <b>Phone no:</b> 911234567839
                        <br><b>Email:</b> <a href="mailto:poonam@tezu.ernet.in"
                           class="hover:underline">poonam@tezu.ernet.in</a>
                     </p>
                  </div>
               </div>
            </div>
            <div class="transform transition duration-500 hover:scale-105">
               <div class="max-w-sm mt-8 rounded overflow-hidden shadow-lg">
                  <img class="max-w-sm object-fill object-center" src="/images/noimage.jpeg">
                  <div class="px-6 py-4">
                     <div class="mb-2 text-left text-lg text-burgundy font-semibold capitalize">dr. saona seth</div>
                     <p class="text-base text-test text-left font-medium leading-relaxed">
                        Assistant Professor<br>Dept. of Applied Sciences <br> <b>Phone no:</b> 911234567839
                        <br><b>Email:</b><a href="mailto:saonas@tezu.ernet.in"
                           class="hover:underline">saonas@tezu.ernet.in</a>
                     </p>
                  </div>
               </div>
            </div>
         </div>

         <!-- prefects information card -->
         <div>
            <p class="mt-60 justify-center text-center capitalize text-3xl text-burgundy font-semibold">- prefects -</p>
         </div>
         <div class="container flex items-center justify-center space-x-40">
            <div class="container transform transition duration-500 hover:scale-105">
               <div class=" max-w-sm mt-8 rounded overflow-hidden shadow-lg">
                  <img class="max-w-sm object-center " src="/images/noimage.jpeg">
                  <div class="px-6 py-4">
                     <div class="mb-2 text-lg text-burgundy font-bold capitalize">Preetishree Gogoi</div>
                     <p class="text-justify text-center text-base text-test font-medium font-medium leading-relaxed">
                        Prefect<br>Dept. of Mathematical Sciences <br> <b>Phone no:</b> 911234567839 <br><b>Email:</b><a
                           href="mailto:msi18009@tezu.ac.in" class="hover:underline"> msi18009@tezu.ac.in</a>
                     </p>
                  </div>
               </div>
            </div>


            <div class="transform transition duration-500 hover:scale-105">
               <div class="max-w-sm mt-8 rounded overflow-hidden shadow-lg">
                  <img class="max-w-sm object-fill object-center" src="/images/noimage.jpeg">
                  <div class="px-6 py-4">
                     <div class="mb-2 text-left text-lg text-burgundy font-semibold capitalize">kaberi changmai</div>
                     <p class="text-base text-test text-left font-medium leading-relaxed">
                        Assistant Prefect<br>Dept. of Mathematical Sciences <br> <b>Phone no:</b> 911234567839
                        <br><b>Email:</b><a href="mailto:msi18014@tezu.ac.in" class="hover:underline">
                           msi18014@tezu.ac.in</a>
                     </p>
                  </div>
               </div>
            </div>
         </div>

         <!-- office staff -->
         <div>
            <p class="mt-60 justify-center text-center capitalize text-3xl text-burgundy font-semibold">- office staff -
            </p>
         </div>
         <div class="container items-center">

            <div class="container items-center transform transition duration-500 hover:scale-105">
               <div class=" max-w-sm mt-8 rounded overflow-hidden shadow-lg">
                  <img class="max-w-sm object-center " src="/images/noimage.jpeg">
                  <div class="px-6 py-4">
                     <div class="mb-2 text-lg text-burgundy font-bold capitalize">firstname surname</div>
                     <p class="text-justify text-center text-base text-test font-medium font-medium leading-relaxed">
                        Caretaker<br> <b>Phone no:</b> 911234567839 <br><b>Email:</b><a
                           href="mailto:poonam@tezu.ernet.in" class="hover:underline"> msi18009@tezu.ac.in</a>
                     </p>
                  </div>
               </div>
            </div>
         </div>

         <!-- mess convenor -->
         <div>
            <p class="mt-60 justify-center text-center capitalize text-3xl text-burgundy font-semibold">- Mess Convenor -</p>
         </div>
         <div class="container flex items-center justify-center space-x-40">

            <div class="container transform transition duration-500 hover:scale-105">
               <div class=" max-w-sm mt-8 rounded overflow-hidden shadow-lg">
                  <img class="max-w-sm object-center " src="/images/noimage.jpeg">
                  <div class="px-6 py-4">
                     <div class="mb-2 text-lg text-burgundy font-bold capitalize">firstname surname</div>
                     <p class="text-justify text-center text-base text-test font-medium font-medium leading-relaxed">
                        Mess convenor<br>dept. of deptname<br><b>Phone no:</b> 911234567839 <br><b>Email:</b><a
                           href="mailto:poonam@tezu.ernet.in" class="hover:underline"> msi18009@tezu.ac.in</a>
                     </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<style scoped>
</style>