<template>
<div>

<div class="container p-4 grid grid-cols-4 grid-rows-4 gap-3">  
      
  <div class="mt-60 transform transition duration-500 hover:scale-105">
    <img class="object-cover w-full h-full" src="/images/building.jpeg" >
  </div>
  <div class="mt-60 transform transition duration-500 hover:scale-105">
    <img class="object-cover w-full h-full" src="/images/building2.jpeg" >
  </div>
  <div class="mt-60 transform transition duration-500 hover:scale-105">
    <img class="object-cover w-full h-full" src="/images/corridor.jpeg" >
  </div>
  <div class="mt-60 transform transition duration-500 hover:scale-105">
    <img class="object-cover w-full h-full" src="/images/deansbuilding.jpeg" >
  </div>
  <div class="mb-60 bg-blue-500 col-span-3 row-span-3">
    <img class="object-cover w-full h-full" src="/images/jobhimain.jpeg" >
  </div>
  <div class="bg-blue-500 transform transition duration-500 hover:scale-105">
    <img class="object-cover w-full h-full" src="/images/building.jpeg" >
  </div>
  <div class="bg-blue-500 transform transition duration-500 hover:scale-105">
    <img class="object-cover w-full h-full" src="/images/building2.jpeg" >
  </div>
  <div class="bg-blue-500 mb-60 transform transition duration-500 hover:scale-105">
    <img class="object-cover w-full h-full" src="/images/building2.jpeg" >
  </div>
</div>
</div>   

   
</template>


<style scoped>
.bg{
  background-color:#fae1e1 ;
}
</style>