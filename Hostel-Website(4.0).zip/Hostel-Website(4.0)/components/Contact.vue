<template>
   <div class="header-margin pb-64">
      <div class="container">
         <!-- web masters informantion cards -->
         <div class="container w-full">
            <p class="mt-32 justify-center text-center capitalize text-4xl text-burgundy font-semibold">- Web Masters -</p>
         </div>
         <div class="container mt-20 flex items-center justify-center space-x-40">

            <div class="container transform transition duration-500 hover:scale-105">
               <div class=" max-w-sm mt-8 rounded overflow-hidden shadow-lg">
                  <img class="max-w-sm object-center " src="/images/noimage.jpeg">
                  <div class="px-6 py-4">
                     <div class="mb-2 text-lg text-burgundy font-bold capitalize">Rachna Harlalka</div>
                     <p class="text-justify text-center text-base text-test font-medium font-medium leading-relaxed">
                        MCA<br>Dept. of Computer Science & Engineering <br> <b>Phone no:</b> 911234567839
                        <br><b>Email:</b> <a href="mailto:csm1005@tezu.ernet.in"
                           class="hover:underline">csm21005@tezu.ernet.in</a>
                     </p>
                  </div>
               </div>
            </div>
            <div class="transform transition duration-500 hover:scale-105">
               <div class="max-w-sm mt-8 rounded overflow-hidden shadow-lg">
                  <img class="max-w-sm object-fill object-center" src="/images/noimage.jpeg">
                  <div class="px-6 py-4">
                     <div class="mb-2 text-left text-lg text-burgundy font-semibold capitalize">Chandrima Paul</div>
                     <p class="text-base text-test text-left font-medium leading-relaxed">
                        B.Tech<br>Dept. of Computer Science & Engineering <br> <b>Phone no:</b> 911234567839
                        <br><b>Email:</b> <a href="mailto:csb21087@tezu.ernet.in" class="hover:underline">csb21087@tezu.ernet.in</a>
                     </p>
                  </div>
               </div>
            </div>


            <div class="transform transition duration-500 hover:scale-105">
               <div class="max-w-sm mt-8 rounded overflow-hidden shadow-lg">
                  <img class="max-w-sm object-fill object-center" src="/images/noimage.jpeg">
                  <div class="px-6 py-4">
                     <div class="mb-2 text-left text-lg text-burgundy font-semibold capitalize">Dhritideepa Sarania</div>
                     <p class="text-base text-test text-left font-medium leading-relaxed">
                        B.Tech<br>Dept. of Computer Science & Engineering<br> <b>Phone no:</b> 911234567839
                        <br><b>Email:</b> <a href="mailto:csb21070@tezu.ernet.in" class="hover:underline">csb21070@tezu.ernet.in</a>
                     </p>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
    </div>
</template>