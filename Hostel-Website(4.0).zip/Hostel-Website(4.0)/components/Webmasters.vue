<template>
<div class="container mb-96">
      <div>
      <ul class="flex items-center justify-center space-x-12 text-m font-inter">
            <li class="nav-item mt-72">
              <NuxtLink to="/" class="nav-link">
              <a class="block mt-4 mr-4 lg:inline-block lg:mt-0  text-red-500 hover:text-red-200 font-bold tracking-wide mr-4">WARDENS</a>
              </NuxtLink>
            </li>

            <li class="nav-item mt-72">
             <NuxtLink to="/prefects" class="nav-link">
               <a class="block mt-4 lg:inline-block lg:mt-0 text-red-500 hover:text-red-200 font-bold tracking-wide mr-4">PREFECTS</a>
             </NuxtLink>
            </li>

            <li class="nav-item mt-72">
             <NuxtLink to="/mess_managers" class="nav-link">
               <a class="block mt-4 lg:inline-block lg:mt-0 text-red-500 hover:text-red-200 font-bold tracking-wide mr-4">MESS MANAGERS</a>
             </NuxtLink>
            </li>  

            <li class="nav-item mt-72">
             <NuxtLink to="/facilities" class="nav-link">
               <a class="block mt-4 lg:inline-block lg:mt-0 text-red-500 hover:text-red-200 font-bold tracking-wide mr-4">OFFICE STAFF</a>
             </NuxtLink>
            </li> 

            <li class="nav-item mt-72">
             <NuxtLink to="/web_masters" class="nav-link">
               <a class="block mt-4 lg:inline-block lg:mt-0 text-red-500 hover:text-red-200 font-bold tracking-wide mr-4">WEB MASTERS</a>
             </NuxtLink>
            </li> 
      </ul>
   </div>          
           

   <!-- administration informantion cards -->
   <div class=" container flex items-center justify-center space-x-10">
      <div class="mt-20 max-w-sm rounded overflow-hidden shadow-lg">
         <img class="max-w-sm transform transition duration-500 hover:scale-110" src="building.jpeg" alt="Sunset in the mountains">
            <div class="px-6 py-4">
               <div class="font-semibold text-l mb-2 text-center">Rachna Di</div>
               <p class="text-gray-700 text-base text-center">
                 
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
               </p>
            </div>
      </div>
         
      <div class="max-w-sm mt-20 rounded overflow-hidden shadow-lg">
         <img class="max-w-sm transform transition duration-500 hover:scale-110" src="building2.jpeg" alt="Sunset in the mountains">
            <div class="px-6 py-4">
               <div class="font-semibold text-l mb-2 text-center">Chandrima Paul</div>
               <p class="text-gray-700 text-base text-center">
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
               </p>
            </div>
      </div>

      <div class="max-w-sm mt-20 rounded overflow-hidden shadow-lg">
         <img class="max-w-sm transform transition duration-500 hover:scale-110" src="deansbuilding.jpeg" alt="Sunset in the mountains">
            <div class="px-6 py-4">
               <div class="font-semibold text-l mb-2 text-center">Dhritideepa Sarania</div>
               <p class="text-gray-700 text-base text-center">
               Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
               </p>
            </div>
      </div>            
   </div>
</div>




</template>