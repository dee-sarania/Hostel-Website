<template>
  <div>
    <Administration/>
  </div>
</template>

<script>
export default{
  name: 'administration'
}
</script>