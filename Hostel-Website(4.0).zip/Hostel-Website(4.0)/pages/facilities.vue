<!--<template>
  <div>
    <div class="container p-8  grid grid-cols-3 grid-rows-5 gap-6">  
       
  <div class="mt-60 mx-auto transform transition duration-500 hover:scale-110  ">
    <img class="object-cover w-full h-full hover:backdrop-opacity-60 " src="building.jpeg" >
  </div>
  <div class="mt-60 transform transition duration-500 hover:scale-110">
    <img class="object-cover w-full h-full hover:blur-lg" src="building2.jpeg" >
  </div>
  <div class="mt-60 transform transition duration-500 hover:scale-110">
    <img class="object-cover w-full h-full" src="corridor.jpeg" >
  </div>
  <div class="mt-20 mb-20 transform transition duration-500 hover:scale-110">
    <img class="object-cover w-full h-full" src="deansbuilding.jpeg" >
  </div>
  <div class="mt-20 mb-20 transform transition duration-500 hover:scale-110">
    <img class="object-cover w-full h-full fit-fill" src="jobhimain.jpeg" >
  </div>
  <div class="mt-20 mb-20 transform transition duration-500 hover:scale-110">
    <img class="object-cover w-full h-full" src="building.jpeg" >
  </div>
  <div class="mt-20 mb-20 transform transition duration-500 hover:scale-110">
    <img class="object-cover w-full h-full" src="building2.jpeg" >
  </div>
  <div class="mb-20 mb-20 transform transition duration-500 hover:scale-110">
    <img class="object-cover w-full h-full" src="building2.jpeg" >
  </div>
</div>
  </div>
</template> -->




<template>
    <div>
      <Facilities/>
    </div>
</template>

<script>
export default{
  name: 'facilities'
}
</script>