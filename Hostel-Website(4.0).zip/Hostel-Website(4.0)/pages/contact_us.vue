<template>
  <div>
    <Contact/>
  </div>
</template>

<script>
export default{
  name: 'contact_us'
}
</script>