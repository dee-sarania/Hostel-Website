import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _f06eb854 = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _783e9ee5 = () => interopDefault(import('..\\pages\\administration.vue' /* webpackChunkName: "pages/administration" */))
const _b6e7b4f2 = () => interopDefault(import('..\\pages\\boarders.vue' /* webpackChunkName: "pages/boarders" */))
const _4303d1a4 = () => interopDefault(import('..\\pages\\contact_us.vue' /* webpackChunkName: "pages/contact_us" */))
const _11704708 = () => interopDefault(import('..\\pages\\facilities.vue' /* webpackChunkName: "pages/facilities" */))
const _382044db = () => interopDefault(import('..\\pages\\gallery.vue' /* webpackChunkName: "pages/gallery" */))
const _93cf7496 = () => interopDefault(import('..\\pages\\homepage.vue' /* webpackChunkName: "pages/homepage" */))
const _658c5816 = () => interopDefault(import('..\\pages\\mess_managers.vue' /* webpackChunkName: "pages/mess_managers" */))
const _a33f7df2 = () => interopDefault(import('..\\pages\\prefects.vue' /* webpackChunkName: "pages/prefects" */))
const _3726c36f = () => interopDefault(import('..\\pages\\web_masters.vue' /* webpackChunkName: "pages/web_masters" */))
const _b0ff02ca = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _f06eb854,
    name: "about"
  }, {
    path: "/administration",
    component: _783e9ee5,
    name: "administration"
  }, {
    path: "/boarders",
    component: _b6e7b4f2,
    name: "boarders"
  }, {
    path: "/contact_us",
    component: _4303d1a4,
    name: "contact_us"
  }, {
    path: "/facilities",
    component: _11704708,
    name: "facilities"
  }, {
    path: "/gallery",
    component: _382044db,
    name: "gallery"
  }, {
    path: "/homepage",
    component: _93cf7496,
    name: "homepage"
  }, {
    path: "/mess_managers",
    component: _658c5816,
    name: "mess_managers"
  }, {
    path: "/prefects",
    component: _a33f7df2,
    name: "prefects"
  }, {
    path: "/web_masters",
    component: _3726c36f,
    name: "web_masters"
  }, {
    path: "/",
    component: _b0ff02ca,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
