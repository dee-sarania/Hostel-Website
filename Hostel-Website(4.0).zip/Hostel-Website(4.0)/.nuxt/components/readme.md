# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Administration>` | `<administration>` (components/Administration.vue)
- `<Button>` | `<button>` (components/Button.vue)
- `<Carousel>` | `<carousel>` (components/Carousel.vue)
- `<Contact>` | `<contact>` (components/Contact.vue)
- `<Facilities>` | `<facilities>` (components/Facilities.vue)
- `<Footer>` | `<footer>` (components/Footer.vue)
- `<Gallery>` | `<gallery>` (components/Gallery.vue)
- `<Homepage>` | `<homepage>` (components/Homepage.vue)
- `<MessManagers>` | `<mess-managers>` (components/MessManagers.vue)
- `<Navbar>` | `<navbar>` (components/Navbar.vue)
- `<Prefects>` | `<prefects>` (components/Prefects.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<Webmasters>` | `<webmasters>` (components/Webmasters.vue)
