export const rooms = [
    {
        "title":"Boarder's room",
        "address":"/images/building.jpeg",
        "description":"Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem, laudantium animi mollitia doloremque facilis, amet doloribus odio architecto endis ipsam accusamus q"
    },
    {
        "title":"Common room",
        "imageName":"/images/building.jpeg",
        "description":"Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem, laudantium animi mollitia doloremque facilis, amet doloribus odio architecto endis ipsam accusamus q"
    },
    {
        "title":"Pantry",
        "address":"/images/building.jpeg",
        "description":"Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem, laudantium animi mollitia doloremque facilis, amet doloribus odio architecto endis ipsam accusamus q"
    },
    
    {
        "title":"Wardrobe facility",
        "address":"/images/building.jpeg",
        "description":"Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem, laudantium animi mollitia doloremque facilis, amet doloribus odio architecto endis ipsam accusamus q"
    }
]