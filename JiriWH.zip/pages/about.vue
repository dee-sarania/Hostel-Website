<template>
    <div>
        <Gallery />
    </div>
</template>