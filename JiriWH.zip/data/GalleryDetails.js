export const photo_credit=[
    {
        "name": "Pahari Khanikar",
        "image":"/images/profile/noimage.jpeg",
        "designation": "Masters",
        "department": "Mass Communication and Journalism",
        "phoneNo": "+91 9876542413",
        "email": "mcm21018@tezu.ernet.in"
    },
]
